package sorting;

import java.util.Arrays;

public class mainProgram {
    public static void main(String[] args){
        // double[] a = { 1.0, 4.0, 6.0, 2.0, 0.0, 5.0, 7.0, 8.0, 9.0, 3.0 };
        double[] a = { 1.0, 2.0, 0.0 };

        double[] b = { 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0 };

        SortingExercises.quickSort(a);

        for (double var : a) {
            System.out.println(var);
        }

    }
}
